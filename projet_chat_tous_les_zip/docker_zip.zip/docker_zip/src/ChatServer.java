import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class ChatServer {
    private static int PORT = 8080;
    private static final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();
    private static final String HISTORY_FILE = "chat_history.txt";
    private static final String AUDIT_LOG_FILE = "chat_audit.log";
    private static final String USERS_FILE = "users.txt";
    private static final Set<String> bannedUsernames = Set.of("admin", "root", "server");

    public static void main(String[] args) {
        startOnPort(PORT);
    }

    public static void startOnPort(int port) {
        System.out.println("Serveur de chat lancé sur le port " + port);
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(clientSocket);
                clients.add(handler);
                new Thread(handler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void broadcast(String message, ClientHandler sender) {
        for (ClientHandler client : clients) {
            if (client != sender) {
                client.sendMessage(message);
            }
        }
        saveMessageToHistory(message);
        logAuditMessage(message, sender);
    }

    private static synchronized void saveMessageToHistory(String message) {
        try (FileWriter fw = new FileWriter(HISTORY_FILE, true)) {
            fw.write(message + "\n");
        } catch (IOException e) {
            System.out.println("Erreur lors de l'enregistrement de l'historique.");
        }
    }

    private static synchronized void logAuditMessage(String message, ClientHandler sender) {
        try (FileWriter fw = new FileWriter(AUDIT_LOG_FILE, true)) {
            String log = String.format("[%s] (%s): %s\n", new Date(), sender.getClientIP(), message);
            fw.write(log);
        } catch (IOException e) {
            System.out.println("Erreur lors de la journalisation.");
        }
    }

    static class ClientHandler implements Runnable {
        private final Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private String username;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                out.println("Entrez votre nom d'utilisateur : ");
                String inputUser = in.readLine();
                if (bannedUsernames.contains(inputUser.toLowerCase())) {
                    out.println("Nom d'utilisateur interdit.");
                    socket.close();
                    return;
                }
                out.println("Entrez votre mot de passe : ");
                String password = in.readLine();
                if (!authenticateUser(inputUser, password)) {
                    out.println("Authentification échouée.");
                    socket.close();
                    return;
                }

                this.username = inputUser;
                sendChatHistory();
                System.out.println(username + " s'est connecté.");
                broadcast(username + " a rejoint le chat.", this);

                String message;
                while ((message = in.readLine()) != null) {
                    if (message.length() > 200) {
                        out.println("Message trop long !");
                        continue;
                    }

                    message = filterMessage(message);
                    System.out.println(username + ": " + message);
                    broadcast(username + ": " + message, this);
                }
            } catch (IOException e) {
                System.out.println("Déconnexion de " + username);
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                }
                clients.remove(this);
                broadcast(username + " a quitté le chat.", this);
            }
        }

        public void sendMessage(String message) {
            out.println(message);
        }

        public String getClientIP() {
            return socket.getInetAddress().getHostAddress();
        }

        private String filterMessage(String message) {
            return message.replaceAll("(?i)\\b(motinterdit1|motinterdit2)\\b", "***");
        }

        private void sendChatHistory() {
            try (BufferedReader reader = new BufferedReader(new FileReader(HISTORY_FILE))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    out.println(line);
                }
            } catch (IOException e) {
                // Fichier peut ne pas encore exister
            }
        }

        private boolean authenticateUser(String user, String pass) {
            try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(":");
                    if (parts.length == 2 && parts[0].equals(user) && parts[1].equals(pass)) {
                        return true;
                    }
                }
            } catch (IOException e) {
                System.out.println("Erreur lors de la lecture de users.txt");
            }
            return false;
        }
    }
}
