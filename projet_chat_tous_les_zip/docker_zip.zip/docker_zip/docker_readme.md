# 🐳 Documentation Docker - Chat Java

## 📋 Prérequis

- Docker installé et configuré
- Docker Compose installé
- X11 forwarding configuré (pour l'interface graphique)
- Système Linux/Unix (pour l'accès X11)

## 🏗️ Architecture Docker

### Images Docker

Le projet utilise deux images Docker distinctes :

- **`chat-server`** : Serveur de chat Java (port 8080)
- **`chat-client-gui`** : Client GUI Java avec interface graphique

### Fichiers Docker

- `Dockerfiles` : Dockerfile pour le serveur
- `Dockerfilec` : Dockerfile pour le client GUI
- `docker-compose.yml` : Orchestration des services

## 🚀 Déploiement

### 1. Construction automatique

Le script `build.sh` automatise tout le processus :

```bash
./build.sh
```

### 2. Déploiement étape par étape

#### Étape 1 : Compilation Java
```bash
# Nettoyer et compiler
rm -rf out
mkdir -p out
javac -d out src/*.java

# Créer le JAR
cd out
jar cfe chat-client-gui.jar StartGUI *
mv chat-client-gui.jar ..
cd ..
```

#### Étape 2 : Construction des images
```bash
# Image serveur
sudo docker build -f Dockerfiles -t chat-server .

# Image client GUI
sudo docker build -f Dockerfilec -t chat-client-gui .
```

#### Étape 3 : Démarrage du serveur
```bash
# Lancer le serveur en arrière-plan
sudo docker-compose up -d server
```

#### Étape 4 : Configuration X11
```bash
# Autoriser Docker à utiliser X11
xhost +local:docker
```

#### Étape 5 : Lancement du client
```bash
# Lancer le client GUI avec accès X11
sudo docker run -it --rm \
  -e DISPLAY=$DISPLAY \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  --network chat_default \
  chat-client-gui
```

## 🔧 Configuration

### Variables d'environnement

- `DISPLAY` : Affichage X11 pour l'interface graphique
- Port serveur : `8080` (défini dans ChatServer.java)

### Réseau Docker

Le projet utilise un réseau Docker personnalisé `chat_default` créé par docker-compose, permettant la communication entre les conteneurs.

### Volumes

- `/tmp/.X11-unix` : Socket X11 pour l'affichage graphique
- Fichiers de données persistants :
  - `users.txt` : Comptes utilisateurs
  - `chat_history.txt` : Historique des messages
  - `chat_audit.log` : Logs d'audit

## 📊 Monitoring

### Vérification des conteneurs
```bash
# Lister les conteneurs actifs
docker ps

# Logs du serveur
docker-compose logs server

# Logs en temps réel
docker-compose logs -f server
```

### État du réseau
```bash
# Inspecter le réseau
docker network inspect chat_default

# Lister les réseaux
docker network ls
```

## 🛠️ Gestion des services

### Démarrage
```bash
# Démarrer tous les services
docker-compose up -d

# Démarrer seulement le serveur
docker-compose up -d server
```

### Arrêt
```bash
# Arrêter tous les services
docker-compose down

# Arrêter et supprimer les volumes
docker-compose down -v
```

### Redémarrage
```bash
# Redémarrer le serveur
docker-compose restart server
```

## 🔍 Dépannage

### Problèmes courants

#### 1. Erreur X11
```bash
# Solution : Autoriser l'accès X11
xhost +local:docker

# Vérifier la variable DISPLAY
echo $DISPLAY
```

#### 2. Problème de réseau
```bash
# Vérifier que le serveur est accessible
docker exec -it <container_id> ping server

# Recréer le réseau
docker-compose down
docker network prune
docker-compose up -d
```

#### 3. Port déjà utilisé
```bash
# Vérifier les ports occupés
netstat -tulpn | grep 8080

# Tuer le processus si nécessaire
sudo kill -9 <PID>
```

### Logs de débogage

```bash
# Logs détaillés du serveur
docker-compose logs --tail=50 server

# Entrer dans le conteneur serveur
docker-compose exec server /bin/bash

# Vérifier les fichiers de configuration
docker-compose exec server cat users.txt
```

## 🔐 Sécurité

### Authentification

Les utilisateurs sont définis dans `users.txt` :
```
alice:password123
bob:securepass
david:azerty
marwa:marwa2004
```

### Audit

Tous les messages sont enregistrés dans `chat_audit.log` avec :
- Timestamp
- Adresse IP du client
- Nom d'utilisateur
- Contenu du message

## 📈 Performance

### Optimisations

- Utilisation de `ConcurrentHashMap` pour la gestion des clients
- Threads séparés pour chaque client
- Mise en cache des messages d'historique

### Limitations

- Taille maximale des messages : 200 caractères
- Noms d'utilisateur interdits : admin, root, server
- Filtrage automatique des mots interdits

## 🔄 Maintenance

### Nettoyage régulier
```bash
# Supprimer les images inutilisées
docker image prune

# Supprimer les conteneurs arrêtés
docker container prune

# Nettoyage complet
docker system prune -a
```

### Sauvegarde des données
```bash
# Sauvegarder les fichiers de données
docker cp <container_id>:/app/chat_history.txt ./backup/
docker cp <container_id>:/app/chat_audit.log ./backup/
docker cp <container_id>:/app/users.txt ./backup/
```

## 📞 Support

Pour les problèmes spécifiques à Docker :

1. Vérifier les logs : `docker-compose logs`
2. Vérifier l'état des conteneurs : `docker ps -a`
3. Vérifier les réseaux : `docker network ls`
4. Redémarrer les services : `docker-compose restart`

---

*Documentation générée pour le projet Chat Java Dockerisé*