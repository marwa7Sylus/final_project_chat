# 🐳 Projet Chat Java Dockerisé (Port 8080)

## 📌 Objectifs pédagogiques
- Créer une image Docker Java
- Respecter les bonnes pratiques (Dockerfile, port, CMD, etc.)
- Déployer localement une application de chat Java

## 📂 Structure du projet
- `Dockerfile` : contient la recette de l'image
- `src/` : les fichiers Java source
- `build.sh` : script de compilation Docker et lancement du conteneur 

## ⚙️ Construction de l’image
```bash
./build.sh
