#!/bin/bash

# 1. Nettoyer et compiler le client GUI Java
echo "Compilation des sources Java client..."
rm -rf out
mkdir -p out
javac -d out src/*.java

echo "Création du JAR exécutable..."
cd out || exit
jar cfe chat-client-gui.jar StartGUI *
mv chat-client-gui.jar ..
cd ..

# 2. Build des images Docker serveur et client
echo "Construction des images Docker..."
sudo docker build -f Dockerfiles -t chat-server .
sudo docker build -f Dockerfilec -t chat-client-gui .

# 3. Démarrer le serveur via docker-compose
echo "Démarrage du serveur..."
sudo docker-compose up -d server

# 4. Autoriser Docker à utiliser X11 pour la GUI
echo "Configuration de l'accès X11..."
xhost +local:docker

# 5. Lancer le client GUI dans le réseau Docker avec accès X11
echo "Lancement du client GUI..."
sudo docker run -it --rm \
  -e DISPLAY=$DISPLAY \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  --network chat_default \
  chat-client-gui
