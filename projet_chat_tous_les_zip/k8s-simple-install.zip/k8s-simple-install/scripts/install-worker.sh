#!/bin/bash
set -e

bash common-setup.sh
bash join-command.sh
