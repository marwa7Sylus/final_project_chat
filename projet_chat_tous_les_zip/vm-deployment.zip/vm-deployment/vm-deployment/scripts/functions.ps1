function Get-VMConfig {
    param([string]$path)
    return Get-Content -Raw -Path $path | ConvertFrom-Json
}

function Connect-ToVCenter {
    param(
        [string]$Server,
        [string]$User,
        [string]$Password
    )
    Connect-VIServer -Server $Server -User $User -Password $Password | Out-Null
}

function Disconnect-FromVCenter {
    param(
        [string]$Server,
        [string]$LogPath
    )
    Disconnect-VIServer -Server $Server -Confirm:$false | Out-Null
    Write-Output "$(Get-Date) : Déconnecté de $Server" | Out-File -Append $LogPath
}

function Create-TemplateFromVM {
    param(
        [psobject]$Config,
        [string]$LogPath
    )

    Write-Output "$(Get-Date) : Création d'une VM temporaire pour le template '$($Config.template)'" | Out-File -Append $LogPath

    # Création d'une VM temporaire vide
    $vm = New-VM -Name "$($Config.template)-VM" `
        -ResourcePool (Get-Cluster | Get-ResourcePool | Select-Object -First 1) `
        -Datastore $Config.datastore -NumCpu 2 -MemoryGB 2 -DiskGB 20 `
        -GuestId "ubuntu64Guest" -NetworkName $Config.network -Confirm:$false

    Write-Output "$(Get-Date) : VM temporaire '$($Config.template)-VM' créée." | Out-File -Append $LogPath

    # Ajout lecteur CD/DVD et montage de l'ISO
    $isoPath = $Config.iso_path 

    if (-not $isoPath) {
        throw "Le chemin de l'ISO n'est pas spécifié dans la configuration (clé 'iso_path')."
    }

    Get-CDDrive -VM $vm | Set-CDDrive -IsoPath $isoPath -StartConnected $true -Confirm:$false
    Write-Output "$(Get-Date) : ISO '$isoPath' monté sur la VM." | Out-File -Append $LogPath

    # Configurer pour entrer dans le BIOS au démarrage (pour choisir l'ISO)
    $spec = New-Object VMware.Vim.VirtualMachineConfigSpec
    $spec.BootOptions = New-Object VMware.Vim.VirtualMachineBootOptions
    $spec.BootOptions.EnterBIOSSetup = $true
    $vm.ExtensionData.ReconfigVM($spec)

    Write-Output "$(Get-Date) : BIOS configuré pour démarrage ISO." | Out-File -Append $LogPath

    # Démarrer la VM pour procéder à l'installation manuelle de l'OS
    Start-VM -VM $vm | Out-Null
    Write-Output "$(Get-Date) : VM temporaire '$($Config.template)-VM' démarrée. Installation manuelle requise." | Out-File -Append $LogPath

    Write-Output "$(Get-Date) : >>> Une fois l'installation terminée, éteignez la VM manuellement et convertissez-la en template." | Out-File -Append $LogPath
}

function Deploy-VMFromTemplate {
    param(
        [psobject]$Config,
        [string]$LogPath
    )

    Write-Output "$(Get-Date) : Vérification du template '$($Config.template)'" | Out-File -Append $LogPath

    $template = Get-Template -Name $Config.template -ErrorAction SilentlyContinue

    if (-not $template) {
        Write-Output "$(Get-Date) : Template introuvable. Création d'une VM temporaire et montage ISO pour installation." | Out-File -Append $LogPath
        Create-TemplateFromVM -Config $Config -LogPath $LogPath
        throw "Template absent : VM temporaire créée avec l'ISO, installation manuelle requise. Reconvertir ensuite en template manuellement."
    }

    Write-Output "$(Get-Date) : Déploiement de la VM '$($Config.vm_name)' à partir du template '$($Config.template)'" | Out-File -Append $LogPath

    $vm = New-VM -Name $Config.vm_name -Template $template -Datastore $Config.datastore -VMHost $Config.host -ErrorAction Stop

    Set-VM -VM $vm -NumCpu $Config.cpu -MemoryGB ($Config.memory / 1024) -Confirm:$false

    Write-Output "$(Get-Date) : VM '$($Config.vm_name)' créée avec succès." | Out-File -Append $LogPath

    Start-VM -VM $vm | Out-Null
    Write-Output "$(Get-Date) : VM '$($Config.vm_name)' démarrée." | Out-File -Append $LogPath
}
