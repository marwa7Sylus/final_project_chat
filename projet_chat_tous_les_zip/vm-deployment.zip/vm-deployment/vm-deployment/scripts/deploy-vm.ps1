# Récupérer le dossier du script
$ScriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Créer dossier logs s'il n'existe pas
$LogFolder = Join-Path -Path $ScriptDir -ChildPath "..\logs"
if (-not (Test-Path $LogFolder)) {
    New-Item -ItemType Directory -Path $LogFolder | Out-Null
}

# Définir le chemin du fichier de log
$LogPath = Join-Path -Path $LogFolder -ChildPath "deployment.log"

# Définir le chemin vers le fichier JSON de config
$ConfigPath = Join-Path -Path $ScriptDir -ChildPath "..\config\vm-config.json"

# Charger fonctions
. "$ScriptDir\functions.ps1"

try {
    Write-Output "$(Get-Date) : Initialisation du déploiement..." | Out-File -Append $LogPath

    # Lire la configuration
    $config = Get-VMConfig -path $ConfigPath

    Write-Output "$(Get-Date) : Début du déploiement de la VM : $($config.vm_name)" | Out-File -Append $LogPath

    # Connexion
    Connect-ToVCenter -Server $config.vcenter -User $config.username -Password $config.password

    # Vérifier si le template existe, sinon le créer automatiquement
    $template = Get-Template -Name $config.template -ErrorAction SilentlyContinue

    if (-not $template) {
        Write-Output "$(Get-Date) : Template '$($config.template)' introuvable, création automatique..." | Out-File -Append $LogPath
        Create-TemplateFromVM -Config $config -LogPath $LogPath
    }

    # Déploiement de la VM à partir du template
    Deploy-VMFromTemplate -Config $config -LogPath $LogPath

    # Déconnexion
    Disconnect-FromVCenter -Server $config.vcenter -LogPath $LogPath

    Write-Output "$(Get-Date) : Déploiement terminé pour : $($config.vm_name)" | Out-File -Append $LogPath
}
catch {
    # Gestion propre de l'erreur
    if ($LogPath) {
        Write-Output "$(Get-Date) : Erreur lors du déploiement - $_" | Out-File -Append $LogPath
    }
    else {
        Write-Error "Erreur détectée mais le chemin du log est inconnu : $_"
    }
}
