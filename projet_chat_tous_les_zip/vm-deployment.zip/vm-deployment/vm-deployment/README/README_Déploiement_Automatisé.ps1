README - Déploiement Automatisé de VM
 VMware
 Description
 Ce projet PowerShell permet d'automatiser le déploiement de machines virtuelles (VM) dans un
 environnement VMware vSphere. Il inclut la gestion des templates, le déploiement de VM et la
 génération de logs.
 Structure du Projet
 root/
 ├── scripts/
 │   └── deploy-vm.ps1        # Script principal de déploiement
 │   └── functions.ps1         # Fonctions utilisées par le déploiement
 ├── config/
 │   └── vm-config.json        # Fichier JSON de configuration
 └── logs/
    └── deployment.log       # Fichier de log généré automatiquement
 Fichier 
functions.ps1
 Fonctions Disponibles
 1. 
Get-VMConfig
 Charge le fichier JSON de configuration et retourne un objet PowerShell.
 Paramètre :
 • 
path : Chemin vers le fichier JSON
 Retour :
 • 
Objet PowerShell représentant la configuration
 2. 
Connect-ToVCenter
 Se connecte au serveur vCenter avec les identifiants fournis.
 1
Paramètres :
 • 
• 
• 
Server : Adresse IP ou DNS du vCenter
 User : Nom d'utilisateur vSphere
 Password : Mot de passe associé
 3. 
Disconnect-FromVCenter
 Ferme proprement la connexion et écrit un message dans le log.
 Paramètres :
 • 
• 
Server : Adresse du vCenter
 LogPath : Chemin du fichier log
 4. 
Create-TemplateFromVM
 Crée une VM temporaire prête pour installation manuelle via ISO.
 Paramètres :
 • 
• 
Config : Objet contenant la configuration (depuis JSON)
 LogPath : Chemin du fichier de log
 5. 
Deploy-VMFromTemplate
 Déploie une VM à partir d'un template si disponible.
 Paramètres :
 • 
• 
Config : Objet de configuration
 LogPath : Chemin du fichier de log
 Fichier 
deploy-vm.ps1
 Fonctionnement du Script
 1. 
2. 
3. 
4. 
5. 
6. 
7. 
8. 
9. 
Création automatique du dossier 
logs/ si inexistant.
 Chargement du fichier de configuration 
vm-config.json
 Connexion au vCenter.
 Vérification de l'existence du template :
 Si présent : déploiement automatique
 Sinon : création d'une VM temporaire pour installation manuelle de l'OS
 Déploiement de la VM si le template est disponible.
 Déconnexion propre du vCenter.
 Gestion des erreurs avec journalisation dans 
deployment.log .
 2
Exemple de Log
 2025-06-16 12:32:00 : Initialisation du déploiement...
 2025-06-16 12:32:02 : Début du déploiement de la VM : Ubuntu-Test
 ...
 2025-06-16 12:33:12 : Déploiement terminé pour : Ubuntu-Test
 Exemple de fichier 
vm-config.json
 {
 }
 "vcenter": "10.11.6.51",
 "username": "administrator@vsphere.local",
 "password": "MotDePasse",
 "vm_name": "VM-Ubuntu-Test",
 "template": "Ubuntu-Template",
 "iso_path": "[datastore1] iso/ubuntu-20.04.iso",
 "datastore": "datastore1",
 "network": "VM Network",
 "host": "esxi01.domaine.local",
 "cpu": 2,
 "memory": 4096
 Prérequis
 • 
• 
• 
• 
• 
• 
PowerCLI installé
 Accès administrateur au vCenter
 Compte utilisateur avec droits suffisants pour gérer VMs et templates
 Ports réseaux ouverts (443)
 Évolutions Possibles
 • 
Intégrer Cloud-init ou Kickstart pour installation OS automatique
 Ajouter tests réseau avant tentative de connexion
 Ajouter notifications par e-mail ou Slack en cas d'erreu