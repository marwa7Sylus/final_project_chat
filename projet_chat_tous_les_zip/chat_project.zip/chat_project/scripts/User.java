public class User {
    private String username;
    private long lastActive;

    public User(String username) {
        this.username = username;
        updateActivity();
    }

    public String getUsername() {
        return username;
    }

    public void updateActivity() {
        this.lastActive = System.currentTimeMillis();
    }

    public boolean isInactive(long timeoutMillis) {
        return (System.currentTimeMillis() - lastActive) > timeoutMillis;
    }
}
