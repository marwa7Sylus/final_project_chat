import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.List; // si tu utilises List ou d'autres structures spécifiques

public class StartGUI {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton connectButton;
    private JLabel statusLabel;
    private JPanel cardPanel;
    private final String USERS_FILE = "users.txt";
    
    // Couleurs modernes (même schéma que ChatClientGUI)
    private static final Color BACKGROUND = new Color(24, 25, 26);
    private static final Color SURFACE = new Color(32, 33, 36);
    private static final Color SURFACE_VARIANT = new Color(40, 41, 44);
    private static final Color PRIMARY = new Color(138, 180, 248);
    private static final Color PRIMARY_VARIANT = new Color(103, 159, 245);
    private static final Color SECONDARY = new Color(154, 160, 166);
    private static final Color ON_SURFACE = new Color(232, 234, 237);
    private static final Color ON_SURFACE_VARIANT = new Color(154, 160, 166);
    private static final Color SUCCESS = new Color(52, 168, 83);
    private static final Color WARNING = new Color(251, 188, 5);
    private static final Color ERROR = new Color(234, 67, 53);

    public StartGUI() {
        initializeFrame();
        createComponents();
        setupEventListeners();
        addAnimations();
        frame.setVisible(true);
    }

    private void initializeFrame() {
        frame = new JFrame("🔐 Chat Sécurisé - Connexion");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 600);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setUndecorated(false);
        
        // Configuration du Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Utiliser le Look and Feel par défaut
        }
    }

    private void createComponents() {
        // Panel principal avec gradient
        JPanel mainPanel = new GradientPanel();
        mainPanel.setLayout(new BorderLayout());
        
        // Panel de connexion (carte)
        cardPanel = createLoginCard();
        
        // Container pour centrer la carte
        JPanel centerContainer = new JPanel(new GridBagLayout());
        centerContainer.setOpaque(false);
        centerContainer.add(cardPanel);
        
        mainPanel.add(centerContainer, BorderLayout.CENTER);
        
        // Footer
        JPanel footerPanel = createFooter();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        frame.add(mainPanel);
    }

    private JPanel createLoginCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Ombre
                g2d.setColor(new Color(0, 0, 0, 30));
                g2d.fillRoundRect(3, 3, getWidth() - 6, getHeight() - 6, 20, 20);
                
                // Carte principale
                g2d.setColor(SURFACE);
                g2d.fillRoundRect(0, 0, getWidth() - 6, getHeight() - 6, 20, 20);
                
                // Bordure subtile
                g2d.setColor(SURFACE_VARIANT);
                g2d.drawRoundRect(0, 0, getWidth() - 6, getHeight() - 6, 20, 20);
            }
        };
        
        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(40, 40, 40, 40));
        card.setPreferredSize(new Dimension(350, 450));
        
        // Header avec icône et titre
        JPanel headerPanel = createHeader();
        card.add(headerPanel);
        
        card.add(Box.createVerticalStrut(30));
        
        // Champs de saisie
        JPanel fieldsPanel = createInputFields();
        card.add(fieldsPanel);
        
        card.add(Box.createVerticalStrut(25));
        
        // Bouton de connexion
        connectButton = new ModernButton("🚀 Se connecter", PRIMARY);
        connectButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        connectButton.setPreferredSize(new Dimension(250, 45));
        connectButton.setMaximumSize(new Dimension(250, 45));
        card.add(connectButton);
        
        card.add(Box.createVerticalStrut(20));
        
        // Status label
        statusLabel = new JLabel("", SwingConstants.CENTER);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(ON_SURFACE_VARIANT);
        card.add(statusLabel);
        
        return card;
    }

    private JPanel createHeader() {
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setOpaque(false);
        
        // Icône
        JLabel iconLabel = new JLabel("💬", SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerPanel.add(iconLabel);
        
        headerPanel.add(Box.createVerticalStrut(15));
        
        // Titre principal
        JLabel titleLabel = new JLabel("Chat Sécurisé", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(ON_SURFACE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerPanel.add(titleLabel);
        
        // Sous-titre
        JLabel subtitleLabel = new JLabel("Connectez-vous pour rejoindre la conversation", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(ON_SURFACE_VARIANT);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerPanel.add(subtitleLabel);
        
        return headerPanel;
    }

    private JPanel createInputFields() {
        JPanel fieldsPanel = new JPanel();
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));
        fieldsPanel.setOpaque(false);
        
        // Champ nom d'utilisateur
        JLabel userLabel = new JLabel("👤 Nom d'utilisateur");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        userLabel.setForeground(ON_SURFACE);
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        fieldsPanel.add(userLabel);
        
        fieldsPanel.add(Box.createVerticalStrut(8));
        
        usernameField = new ModernTextField();
        usernameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        usernameField.setAlignmentX(Component.LEFT_ALIGNMENT);
        fieldsPanel.add(usernameField);
        
        fieldsPanel.add(Box.createVerticalStrut(20));
        
        // Champ mot de passe
        JLabel passLabel = new JLabel("🔒 Mot de passe");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        passLabel.setForeground(ON_SURFACE);
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        fieldsPanel.add(passLabel);
        
        fieldsPanel.add(Box.createVerticalStrut(8));
        
        passwordField = new ModernPasswordField();
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        fieldsPanel.add(passwordField);
        
        return fieldsPanel;
    }

    private JPanel createFooter() {
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footerPanel.setOpaque(false);
        footerPanel.setBorder(new EmptyBorder(0, 0, 20, 0));
        
        JLabel footerLabel = new JLabel("💡 Utilisez vos identifiants pour accéder au chat");
        footerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        footerLabel.setForeground(ON_SURFACE_VARIANT);
        footerPanel.add(footerLabel);
        
        return footerPanel;
    }

    private void setupEventListeners() {
        connectButton.addActionListener(e -> attemptLogin());
        passwordField.addActionListener(e -> attemptLogin());
        usernameField.addActionListener(e -> passwordField.requestFocus());
        
        // Focus automatique sur le champ username
        SwingUtilities.invokeLater(() -> usernameField.requestFocus());
    }

    private void addAnimations() {
        // Animation d'apparition de la carte
        cardPanel.setOpaque(false);
        Timer slideTimer = new Timer(30, new ActionListener() {
            private int step = 0;
            private final int maxSteps = 20;
            
            @Override
            public void actionPerformed(ActionEvent e) {
                step++;
                float progress = (float) step / maxSteps;
                
                // Animation d'échelle
                float scale = 0.8f + (0.2f * progress);
                
                if (step >= maxSteps) {
                    ((Timer) e.getSource()).stop();
                }
                
                frame.repaint();
            }
        });
        slideTimer.start();
    }

    private void attemptLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            updateStatus("⚠️ Veuillez remplir tous les champs", WARNING);
            return;
        }

        // Animation du bouton de connexion
        connectButton.setEnabled(false);
        connectButton.setText("🔄 Connexion...");
        
        // Simulation d'un délai pour l'authentification
        Timer authTimer = new Timer(800, e -> {
            if (authenticateUser(username, password)) {
                updateStatus("✅ Connexion réussie ! Ouverture du chat...", SUCCESS);
                
                Timer successTimer = new Timer(1000, ev -> {
                    frame.dispose();
                    ChatClientGUI.launchWithCredentials(username, password);
                });
                successTimer.setRepeats(false);
                successTimer.start();
            } else {
                updateStatus("❌ Nom d'utilisateur ou mot de passe incorrect", ERROR);
                connectButton.setEnabled(true);
                connectButton.setText("🚀 Se connecter");
                passwordField.setText("");
                
                // Animation de secousse pour la carte
                shakeCard();
            }
        });
        authTimer.setRepeats(false);
        authTimer.start();
    }

    private void updateStatus(String message, Color color) {
        statusLabel.setText(message);
        statusLabel.setForeground(color);
        
        // Animation de fade-in pour le message
        statusLabel.setOpaque(false);
        Timer fadeTimer = new Timer(50, new ActionListener() {
            private float alpha = 0.0f;
            
            @Override
            public void actionPerformed(ActionEvent e) {
                alpha += 0.1f;
                if (alpha >= 1.0f) {
                    alpha = 1.0f;
                    ((Timer) e.getSource()).stop();
                }
                statusLabel.repaint();
            }
        });
        fadeTimer.start();
    }

    private void shakeCard() {
        Point originalLocation = cardPanel.getLocation();
        Timer shakeTimer = new Timer(50, new ActionListener() {
            private int count = 0;
            private final int maxCount = 8;
            
            @Override
            public void actionPerformed(ActionEvent e) {
                count++;
                if (count >= maxCount) {
                    cardPanel.setLocation(originalLocation);
                    ((Timer) e.getSource()).stop();
                    return;
                }
                
                int offset = (count % 2 == 0) ? 5 : -5;
                cardPanel.setLocation(originalLocation.x + offset, originalLocation.y);
                frame.repaint();
            }
        });
        shakeTimer.start();
    }

    private boolean authenticateUser(String username, String password) {
        File file = new File(USERS_FILE);
        
        if (!file.exists()) {
            return false;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file, java.nio.charset.StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || !line.contains(":")) {
                    continue;
                }
                
                String[] parts = line.split(":", 2);
                if (parts.length == 2) {
                    String fileUsername = parts[0].trim();
                    String filePassword = parts[1].trim();
                    
                    if (fileUsername.equals(username) && filePassword.equals(password)) {
                        return true;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier users.txt: " + e.getMessage());
        }

        return false;
    }

    private void createDefaultUsersFile() {
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            try (PrintWriter writer = new PrintWriter(new FileWriter(file, java.nio.charset.StandardCharsets.UTF_8))) {
                writer.println("alice:password123");
                writer.println("bob:securepass");
                writer.println("david:azerty");
                writer.println("marwa:marwa2004");
                System.out.println("Fichier users.txt créé avec les utilisateurs par défaut.");
            } catch (IOException e) {
                System.out.println("Erreur lors de la création du fichier users.txt: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StartGUI gui = new StartGUI();
            gui.createDefaultUsersFile();
        });
    }

    // Classes pour les composants modernes
    class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            
            GradientPaint gradient = new GradientPaint(
                0, 0, BACKGROUND,
                0, getHeight(), new Color(BACKGROUND.getRed() + 8, BACKGROUND.getGreen() + 8, BACKGROUND.getBlue() + 8)
            );
            g2d.setPaint(gradient);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    class ModernButton extends JButton {
        private Color backgroundColor;
        private boolean isHovered = false;
        private boolean isPressed = false;
        
        public ModernButton(String text, Color backgroundColor) {
            super(text);
            this.backgroundColor = backgroundColor;
            setOpaque(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setFocusPainted(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    isHovered = true;
                    repaint();
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    repaint();
                }
                
                @Override
                public void mousePressed(MouseEvent e) {
                    isPressed = true;
                    repaint();
                }
                
                @Override
                public void mouseReleased(MouseEvent e) {
                    isPressed = false;
                    repaint();
                }
            });
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            Color color = backgroundColor;
            if (isPressed) {
                color = backgroundColor.darker();
            } else if (isHovered) {
                color = backgroundColor.brighter();
            }
            
            g2d.setColor(color);
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            
            // Effet de brillance
            if (isHovered) {
                g2d.setColor(new Color(255, 255, 255, 30));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight() / 2, 12, 12);
            }
            
            super.paintComponent(g);
        }
    }

    class ModernTextField extends JTextField {
        public ModernTextField() {
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
            setBackground(SURFACE_VARIANT);
            setForeground(ON_SURFACE);
            setCaretColor(PRIMARY);
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 0, 0, 0), 1, true),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
            ));
            
            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(PRIMARY, 2, true),
                        BorderFactory.createEmptyBorder(9, 14, 9, 14)
                    ));
                }
                
                @Override
                public void focusLost(FocusEvent e) {
                    setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(0, 0, 0, 0), 1, true),
                        BorderFactory.createEmptyBorder(10, 15, 10, 15)
                    ));
                }
            });
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            g2d.setColor(getBackground());
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            
            super.paintComponent(g);
        }
    }

    class ModernPasswordField extends JPasswordField {
        public ModernPasswordField() {
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
            setBackground(SURFACE_VARIANT);
            setForeground(ON_SURFACE);
            setCaretColor(PRIMARY);
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 0, 0, 0), 1, true),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
            ));
            
            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(PRIMARY, 2, true),
                        BorderFactory.createEmptyBorder(9, 14, 9, 14)
                    ));
                }
                
                @Override
                public void focusLost(FocusEvent e) {
                    setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(0, 0, 0, 0), 1, true),
                        BorderFactory.createEmptyBorder(10, 15, 10, 15)
                    ));
                }
            });
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            g2d.setColor(getBackground());
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            
            super.paintComponent(g);
        }
    }
}
