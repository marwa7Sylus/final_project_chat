import java.io.*;
import java.net.*;

public class ChatClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 12345);
        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));

        Thread receiver = new Thread(() -> {
            String line;
            try {
                while ((line = input.readLine()) != null) {
                    System.out.println("🔔 " + line);
                }
            } catch (IOException e) {
                System.out.println("Connexion perdue.");
            }
        });
        receiver.start();

        while (true) {
            String userInput = keyboard.readLine();
            out.println(userInput);
        }
    }
}
