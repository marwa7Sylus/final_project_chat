import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatClientGUI extends JFrame {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private JPanel chatPanel;
    private JScrollPane scrollPane;
    private JTextField inputField;
    private JButton sendButton;
    private JLabel statusLabel;
    private JLabel userCountLabel;
    private String username;
    
    // Couleurs modernes
    private static final Color BACKGROUND = new Color(24, 25, 26);
    private static final Color SURFACE = new Color(32, 33, 36);
    private static final Color SURFACE_VARIANT = new Color(40, 41, 44);
    private static final Color PRIMARY = new Color(138, 180, 248);
    private static final Color PRIMARY_VARIANT = new Color(103, 159, 245);
    private static final Color SECONDARY = new Color(154, 160, 166);
    private static final Color ON_SURFACE = new Color(232, 234, 237);
    private static final Color ON_SURFACE_VARIANT = new Color(154, 160, 166);
    private static final Color SUCCESS = new Color(52, 168, 83);
    private static final Color WARNING = new Color(251, 188, 5);
    private static final Color ERROR = new Color(234, 67, 53);

    public ChatClientGUI(String host, int port, String username, String password) {
        this.username = username;
        initializeUI();
        connectToServer(host, port, username, password);
    }

    private void initializeUI() {
        setTitle("💬 Chat Moderne - " + username);
        setSize(800, 600);
        setMinimumSize(new Dimension(600, 400));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Définir l'icône de l'application
        try {
            setIconImage(createChatIcon());
        } catch (Exception e) {
            // Ignorer si l'icône ne peut pas être créée
        }

        // Configuration du Look and Feel
        setupLookAndFeel();
        
        // Panel principal avec gradient
        JPanel mainPanel = new GradientPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Header avec titre et informations
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Zone de chat
        JPanel chatContainer = createChatContainer();
        mainPanel.add(chatContainer, BorderLayout.CENTER);
        
        // Zone de saisie
        JPanel inputContainer = createInputContainer();
        mainPanel.add(inputContainer, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Effets de fenêtre
        addWindowEffects();
        
        setVisible(true);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        headerPanel.setBorder(new EmptyBorder(0, 0, 15, 0));
        
        // Titre principal
        JLabel titleLabel = new JLabel("💬 Chat Sécurisé", SwingConstants.LEFT);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(ON_SURFACE);
        
        // Informations utilisateur
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        userPanel.setOpaque(false);
        
        JLabel userLabel = new JLabel("👤 " + username);
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userLabel.setForeground(PRIMARY);
        
        userCountLabel = new JLabel("🌐 En ligne: 1");
        userCountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        userCountLabel.setForeground(ON_SURFACE_VARIANT);
        
        statusLabel = new JLabel("🔄 Connexion...");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(WARNING);
        
        userPanel.add(userLabel);
        userPanel.add(userCountLabel);
        userPanel.add(statusLabel);
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(userPanel, BorderLayout.EAST);
        
        return headerPanel;
    }

    private JPanel createChatContainer() {
        chatPanel = new JPanel();
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        chatPanel.setBackground(SURFACE);
        chatPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        scrollPane = new JScrollPane(chatPanel);
        scrollPane.setBackground(SURFACE);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(SURFACE_VARIANT, 1, true),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        // Personnaliser la barre de défilement
        styleScrollBar(scrollPane);
        
        JPanel container = new JPanel(new BorderLayout());
        container.setOpaque(false);
        container.add(scrollPane, BorderLayout.CENTER);
        
        return container;
    }

    private JPanel createInputContainer() {
        JPanel inputContainer = new JPanel(new BorderLayout(10, 0));
        inputContainer.setOpaque(false);
        inputContainer.setBorder(new EmptyBorder(15, 0, 0, 0));
        
        // Champ de saisie moderne
        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        inputField.setBackground(SURFACE);
        inputField.setForeground(ON_SURFACE);
        inputField.setCaretColor(PRIMARY);
        inputField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(SURFACE_VARIANT, 1, true),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        
        // Placeholder effect
        inputField.setText("Tapez votre message...");
        inputField.setForeground(ON_SURFACE_VARIANT);
        inputField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (inputField.getText().equals("Tapez votre message...")) {
                    inputField.setText("");
                    inputField.setForeground(ON_SURFACE);
                }
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                if (inputField.getText().isEmpty()) {
                    inputField.setText("Tapez votre message...");
                    inputField.setForeground(ON_SURFACE_VARIANT);
                }
            }
        });
        
        // Bouton d'envoi moderne
        sendButton = new ModernButton("📤 Envoyer", PRIMARY);
        sendButton.setPreferredSize(new Dimension(120, 45));
        
        inputContainer.add(inputField, BorderLayout.CENTER);
        inputContainer.add(sendButton, BorderLayout.EAST);
        
        // Actions
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());
        
        return inputContainer;
    }

    private void connectToServer(String host, int port, String username, String password) {
        new Thread(() -> {
            try {
                SwingUtilities.invokeLater(() -> {
                    statusLabel.setText("🔄 Connexion...");
                    statusLabel.setForeground(WARNING);
                });
                
                socket = new Socket(host, port);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // Authentification
                String prompt1 = in.readLine();
                out.println(username);
                String prompt2 = in.readLine();
                out.println(password);
                String response = in.readLine();
                
                if (response == null || response.contains("échouée") || response.contains("interdit")) {
                    SwingUtilities.invokeLater(() -> {
                        statusLabel.setText("❌ Échec authentification");
                        statusLabel.setForeground(ERROR);
                        showError("Authentification échouée");
                    });
                    return;
                }

                SwingUtilities.invokeLater(() -> {
                    statusLabel.setText("✅ Connecté");
                    statusLabel.setForeground(SUCCESS);
                });
                
                if (!response.equals("AUTH_SUCCESS")) {
                    addMessage(response, "system");
                }

                // Écouter les messages
                String line;
                while ((line = in.readLine()) != null) {
                    final String message = line;
                    SwingUtilities.invokeLater(() -> {
                        // Ne pas afficher les messages qu'on a déjà affichés côté client
                        if (!message.startsWith(username + ":")) {
                            addMessage(message, detectMessageType(message));
                        }
                    });
                }
                
            } catch (IOException e) {
                SwingUtilities.invokeLater(() -> {
                    statusLabel.setText("❌ Connexion perdue");
                    statusLabel.setForeground(ERROR);
                    showError("Connexion perdue");
                });
            }
        }).start();
    }

    private void addMessage(String message, String type) {
        JPanel messagePanel = new MessagePanel(message, type, username);
        chatPanel.add(messagePanel);
        chatPanel.add(Box.createVerticalStrut(8));
        
        // Scroll automatique
        SwingUtilities.invokeLater(() -> {
            scrollPane.revalidate();
            scrollPane.repaint();
            JScrollBar vertical = scrollPane.getVerticalScrollBar();
            vertical.setValue(vertical.getMaximum());
        });
    }

    private String detectMessageType(String message) {
        if (message.contains("a rejoint") || message.contains("a quitté")) {
            return "system";
        } else if (message.startsWith(username + ":")) {
            return "own";
        } else {
            return "other";
        }
    }

    private void sendMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty() && !message.equals("Tapez votre message...")) {
            // Afficher immédiatement le message envoyé côté client
            addMessage(username + ": " + message, "own");
            
            // Envoyer au serveur
            out.println(message);
            inputField.setText("");
            inputField.requestFocus();
        }
    }

    private void setupLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Utiliser le Look and Feel par défaut
        }
    }

    private void styleScrollBar(JScrollPane scrollPane) {
        JScrollBar verticalBar = scrollPane.getVerticalScrollBar();
        verticalBar.setBackground(SURFACE);
        verticalBar.setUI(new javax.swing.plaf.basic.BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = SURFACE_VARIANT;
                this.trackColor = SURFACE;
            }
            
            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createInvisibleButton();
            }
            
            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createInvisibleButton();
            }
            
            private JButton createInvisibleButton() {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(0, 0));
                button.setMinimumSize(new Dimension(0, 0));
                button.setMaximumSize(new Dimension(0, 0));
                return button;
            }
        });
    }

    private void addWindowEffects() {
        // Effet de fade-in au démarrage
       // setOpacity(0.0f);
        Timer fadeTimer = new Timer(50, new ActionListener() {
            float opacity = 0.0f;
            
            @Override
            public void actionPerformed(ActionEvent e) {
                opacity += 0.1f;
                if (opacity >= 1.0f) {
                    opacity = 1.0f;
                    ((Timer) e.getSource()).stop();
                }
              //  setOpacity(opacity);
            }
        });
        fadeTimer.start();
    }

    private Image createChatIcon() {
        BufferedImage icon = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = icon.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(PRIMARY);
        g2d.fillRoundRect(4, 4, 24, 24, 8, 8);
        g2d.setColor(Color.WHITE);
        g2d.fillOval(8, 10, 4, 4);
        g2d.fillOval(14, 10, 4, 4);
        g2d.fillOval(20, 10, 4, 4);
        g2d.dispose();
        return icon;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Erreur", JOptionPane.ERROR_MESSAGE);
    }

    public static void launchWithCredentials(String username, String password) {
        SwingUtilities.invokeLater(() -> new ChatClientGUI("localhost",12345, username, password));
    }

    // Classe pour le panel avec gradient
    class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            
            GradientPaint gradient = new GradientPaint(
                0, 0, BACKGROUND,
                0, getHeight(), new Color(BACKGROUND.getRed() + 5, BACKGROUND.getGreen() + 5, BACKGROUND.getBlue() + 5)
            );
            g2d.setPaint(gradient);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    // Classe pour les boutons modernes
    class ModernButton extends JButton {
        private Color backgroundColor;
        private boolean isHovered = false;
        
        public ModernButton(String text, Color backgroundColor) {
            super(text);
            this.backgroundColor = backgroundColor;
            setOpaque(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 12));
            setFocusPainted(false);
            
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    isHovered = true;
                    repaint();
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    repaint();
                }
            });
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            Color color = isHovered ? backgroundColor.brighter() : backgroundColor;
            g2d.setColor(color);
            g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            
            super.paintComponent(g);
        }
    }

    // Classe pour les bulles de messages
    class MessagePanel extends JPanel {
        private String message;
        private String type;
        private String currentUser;
        
        public MessagePanel(String message, String type, String currentUser) {
            this.message = message;
            this.type = type;
            this.currentUser = currentUser;
            
            setOpaque(false);
            setLayout(new BorderLayout());
            setupMessage();
        }
        
        private void setupMessage() {
            JPanel bubble = new JPanel();
            bubble.setLayout(new BorderLayout(5, 5));
            bubble.setBorder(new EmptyBorder(10, 15, 10, 15));
            
            Color bubbleColor;
            Color textColor;
            int alignment;
            
            switch (type) {
                case "own":
                    bubbleColor = PRIMARY;
                    textColor = Color.WHITE;
                    alignment = FlowLayout.RIGHT;
                    break;
                case "system":
                    bubbleColor = SURFACE_VARIANT;
                    textColor = ON_SURFACE_VARIANT;
                    alignment = FlowLayout.CENTER;
                    break;
                default:
                    bubbleColor = new Color(SURFACE_VARIANT.getRed() + 10, SURFACE_VARIANT.getGreen() + 10, SURFACE_VARIANT.getBlue() + 10);
                    textColor = ON_SURFACE;
                    alignment = FlowLayout.LEFT;
                    break;
            }
            
            bubble.setBackground(bubbleColor);
            
            // Texte du message - enlever le nom d'utilisateur pour les messages propres
            String displayMessage = message;
            if (type.equals("own") && message.startsWith(currentUser + ":")) {
                displayMessage = message.substring((currentUser + ": ").length());
            }
            
            JLabel messageLabel = new JLabel("<html><div style='max-width: 300px;'>" + 
                displayMessage.replace("<", "&lt;").replace(">", "&gt;") + "</div></html>");
            messageLabel.setForeground(textColor);
            messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            
            // Timestamp
            String timestamp = new SimpleDateFormat("HH:mm").format(new Date());
            JLabel timeLabel = new JLabel(timestamp);
            timeLabel.setForeground(new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), 150));
            timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            
            bubble.add(messageLabel, BorderLayout.CENTER);
            bubble.add(timeLabel, BorderLayout.SOUTH);
            
            JPanel container = new JPanel(new FlowLayout(alignment, 10, 0));
            container.setOpaque(false);
            container.add(bubble);
            
            add(container, BorderLayout.CENTER);
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Dessiner les bulles avec coins arrondis
            Component bubble = ((JPanel) getComponent(0)).getComponent(0);
            if (bubble instanceof JPanel) {
                JPanel bubblePanel = (JPanel) bubble;
                g2d.setColor(bubblePanel.getBackground());
                g2d.fillRoundRect(bubblePanel.getX(), bubblePanel.getY(), 
                    bubblePanel.getWidth(), bubblePanel.getHeight(), 15, 15);
            }
        }
    }
}
