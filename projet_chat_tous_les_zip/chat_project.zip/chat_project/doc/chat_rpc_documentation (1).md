# Chat RPC - Système de Chat Multi-Utilisateur

## 📋 Vue d'ensemble

Système de chat en temps réel avec architecture client-serveur utilisant les sockets TCP/IP. Interface graphique moderne avec authentification et journalisation complète.

## 🏗️ Architecture

- **ChatServer.java** - Serveur central multi-threadé
- **ChatClientGUI.java** - Client avec interface graphique
- **StartGUI.java** - Interface de connexion
- **ChatClient.java** - Client ligne de commande
- **User.class** - Gestion des utilisateurs

## ⚡️ Installation & Lancement

### Prérequis

- Java 8+
- Port 12345 disponible

### Compilation

```bash
javac *.java
```

### Démarrage

```bash
# 1. Lancer le serveur
java ChatServer

# 2. Lancer le client GUI
java StartGUI

# Ou client console
java ChatClient
```

## 👥 Utilisateurs par défaut

```txt
alice:password123
bob:securepass
david:azerty
marwa:marwa2004
```

## 🔧 Configuration

- **Port**: 12345 (TCP)
- **Fichiers**:
  - `users.txt` - Base utilisateurs (format: `username:password`)
  - `chat_history.txt` - Historique des messages
  - `chat_audit.log` - Journal d'audit complet

## 🚀 Fonctionnalités

### Sécurité

- Authentification obligatoire
- Noms interdits (admin, root, server)
- Filtrage des messages offensants
- Limite 200 caractères par message
- Audit complet avec IP/timestamps

### Interface

- Thème sombre moderne
- Bulles de messages stylisées
- Animations et effets visuels
- Notifications connexion/déconnexion
- Historique persistant

## 📊 Structure des fichiers

```txt
projet-chat-rpc/
├── ChatServer.java
├── ChatClientGUI.java
├── StartGUI.java
├── ChatClient.java
├── User.class
├── users.txt
├── chat_history.txt
└── chat_audit.log
```

## 🔒 Protocole de Communication

### Authentification

1. Client → Serveur: `nom_utilisateur`
2. Serveur → Client: `"Entrez votre mot de passe :"`
3. Client → Serveur: `mot_de_passe`
4. Serveur → Client: confirmation/échec

### Messages

- Client → Serveur: `message_texte`
- Serveur → Tous: `nom_utilisateur: message_texte`

## 🛠️ Dépannage

### Problèmes courants

- **Connexion refusée**: Vérifier serveur démarré + port 12345 libre
- **Authentification échouée**: Contrôler `users.txt` (format: `user:pass`)
- **Messages non affichés**: Vérifier connexion réseau

## 🔮 Extensions possibles

- Salles de chat multiples
- Messages privés
- Partage de fichiers
- Base de données (MySQL/PostgreSQL)
- Connexions SSL/TLS
- API REST mobile

## 📝 Logs

- **Audit**: `[timestamp] (IP): action`
- **Historique**: `utilisateur: message`

---

*Système développé avec Java Swing - Architecture modulaire et extensible*

